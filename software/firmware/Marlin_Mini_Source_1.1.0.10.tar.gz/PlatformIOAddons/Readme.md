This folder contains the project file to build and install Marlin firmware using the PlatformIO development environment.

1) Install platformio (See http://platformio.org/)

....

x) From this directory
  platformio run

